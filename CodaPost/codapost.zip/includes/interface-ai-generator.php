<?php

interface AI_Generator {
    public function generate_content($prompt);
}